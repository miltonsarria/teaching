import cv2
import numpy as np
import matplotlib.pyplot as plt



img = cv2.imread('bookpage.jpg')
retval, threshold = cv2.threshold(img, 10, 255, cv2.THRESH_BINARY)
plt.subplot(2,1,1)
plt.imshow(img)
plt.subplot(2,1,2)
plt.imshow(threshold)

plt.show()

#
